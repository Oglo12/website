
# Nerd Fonts

This is an archived font from a Nerd Fonts release.

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/
